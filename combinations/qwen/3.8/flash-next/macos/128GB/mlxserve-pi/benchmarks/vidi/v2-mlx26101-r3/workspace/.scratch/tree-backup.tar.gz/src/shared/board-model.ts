import * as Y from 'yjs';
import {
  DEFAULT_STICKY_COLOR,
  SHAPE_DEFAULT_SIZE_WORLD,
  STICKY_COLORS,
  STICKY_SIZE_WORLD,
  isFillColor,
  isPenColor,
  isPenThickness,
  isShapeKind,
  isStrokeColor,
  isTextSize,
  isTextWidthMode,
  type FillColor,
  type PenColor,
  type PenThickness,
  type ShapeKind,
  type StickyColor,
  type StrokeColor,
  type TextSize,
  type TextWidthMode,
} from './config';
import { rectContains, unionRects, type Point, type Rect } from './geometry';
import { readEndpoint, type Endpoint } from './geometry/connector-geometry';

/**
 * The board document schema and every mutation of it.
 *
 * This module is framework-free on purpose: the client renders a snapshot of it today,
 * story 3 syncs the same document between peers and story 4 persists it (the Durable
 * Object imports this file to validate and migrate), so the shape below is the wire and
 * storage contract from the start.
 *
 * ```text
 * Y.Doc
 *   meta: Y.Map    { schemaVersion: 1 }
 *   objects: Y.Map<string /* id *\/, Y.Map>
 *     <id>: Y.Map {
 *       type: 'sticky'
 *       x: number, y: number   // top-left, world units
 *       width: number, height: number   // world units; absent before story 7
 *       color: StickyColor
 *       text: Y.Text
 *       z: number              // stacking; higher is on top
 *       createdAt: number      // epoch ms
 *     }
 *     <id>: Y.Map {            // a text object (story 9), which has no colour and instead:
 *       type: 'text', size: TextSize, widthMode: 'auto' | 'fixed', createdBy: string
 *     }
 *     <id>: Y.Map {            // a shape (story 10): a box, an oval or a diamond with a label
 *       type: 'shape', kind: ShapeKind, fill: FillColor | 'none', stroke: StrokeColor,
 *       label: Y.Text, width, height, createdBy: string
 *     }
 *     <id>: Y.Map {            // an arrow (story 10); its own box is derived, see `from`/`to`
 *       type: 'connector', from: Endpoint, to: Endpoint, createdBy: string
 *     }
 *     <id>: Y.Map {            // a pen stroke (story 11): a path inside the box it was drawn in
 *       type: 'stroke', points: number[],   // flat [x0,y0,x1,y1,…], relative to x/y
 *       baseWidth, baseHeight: number,      // the box it was drawn at, which a resize scales against
 *       color: PenColor, thickness: PenThickness, createdBy: string
 *     }
 *     <id>: Y.Map {            // an image (story 12): a picture whose bytes live outside the document
 *       type: 'image', assetKey: string | null,  // null until the upload lands; then '<boardId>/<id>'
 *       contentType: string,                     // what the bytes were found to be, and what they are
 *                                                  // served as - the bucket is not asked again
 *       naturalWidth, naturalHeight: number,     // the picture's own pixels: the ratio every box keeps
 *       status: 'uploading' | 'ready' | 'failed', uploadStartedAt: number, uploaderId?: string
 *     }
 * ```
 *
 * Two types are written by story 10 and read here: `shape`, which is an ordinary object with three
 * extra fields, and `connector`, whose `x`/`y`/`width`/`height` are not its own but worked out from
 * the objects its two ends are fastened to - the one place in this module where a box is a
 * consequence rather than a fact (see {@link registerDerivedBounds}).
 *
 * Every successful mutation is exactly one `doc.transact(fn, LOCAL_ORIGIN)`; a rejected
 * mutation (stale id, unknown colour, non-finite coordinates, pointless re-stack) returns
 * `false` before a transaction is opened, so it emits no update and will cost no sync
 * traffic in story 3. The module never throws for user-driven input.
 */

/** Origin of every local mutation; story 8 uses it for undo, story 3 to avoid echo. */
export const LOCAL_ORIGIN: unique symbol = Symbol('vidi6-local');

/** Document schema version written by {@link initDoc}. */
export const SCHEMA_VERSION = 1;

/** Names of the top-level shared types of the document. */
export const META_MAP = 'meta';
export const OBJECTS_MAP = 'objects';

/** The `type` discriminator of a sticky note. Unknown values are skipped by the reader. */
export const STICKY_TYPE = 'sticky';

/**
 * The `type` discriminator of a shape (story 10) and of an arrow between objects (story 10).
 *
 * These two live here rather than in `objects/shape.ts` and `objects/connector.ts`, next to the
 * functions that write them, because the reader below has to know the names to give a shape its
 * default size and to leave an arrow's box to be worked out - and those modules import this one to
 * be written at all. Each of them re-exports the name it owns, so the code that *writes* a shape
 * keeps saying `SHAPE_TYPE` from where it stands.
 */
export const SHAPE_TYPE = 'shape';
export const CONNECTOR_TYPE = 'connector';

/**
 * The `type` discriminator of a pen stroke (story 11): a freehand line, stored as a path inside the
 * box it was drawn in.
 *
 * Registered here for the same reason the two above are - the reader below has to know the name, both
 * to read the stroke's own four fields and to refuse a stroke whose path cannot be read - and
 * `objects/stroke.ts` re-exports it for the code that writes strokes.
 */
export const STROKE_TYPE = 'stroke';

/**
 * The `type` discriminator of an image (story 12): a picture whose bytes live outside the document.
 *
 * Registered here for the same reason as the two above, and with the same consequence: the reader below
 * learns the name so it can read an image's own fields and refuse an image whose size cannot be read,
 * and `objects/image.ts` re-exports the name for the code that writes images.
 *
 * What is *not* here is worth as much as what is. A sticky note carries its own words, in a `Y.Text`,
 * because words are small and merge. A picture is two megabytes of bytes that do not merge with anything,
 * so the document carries a *reference* to it - `assetKey`, a pointer into the bucket - and the bytes are
 * fetched separately, once, and cached for a year. A board with forty photographs on it is still a small
 * document, which is the only way it can stay a document that syncs in a blink.
 */
export const IMAGE_TYPE = 'image';

/**
 * Where an image's upload has got to (story 12).
 *
 * Three values, and they are the whole of what anybody knows about an upload: `uploading` from the moment
 * the placeholder is written until the answer comes back, then `ready` or `failed`. There is no `queued`,
 * no `paused` and no `cancelling`, because nothing in this design queues, pauses or cancels anything.
 *
 * A fourth thing the screen shows - "that upload never finished" - is deliberately not in here. It is a
 * read of `uploading` against a clock (see {@link IMAGE_UPLOAD_STALE_MS}), not a state anything writes,
 * which is what lets it be true for everybody at once without a message about timeouts ever having to be
 * sent.
 */
export type ImageUploadStatus = 'uploading' | 'ready' | 'failed';

/** Is this one of the three upload statuses? */
export function isImageUploadStatus(value: unknown): value is ImageUploadStatus {
  return value === 'uploading' || value === 'ready' || value === 'failed';
}

/**
 * An image (story 12), as the board reads it.
 *
 * `naturalWidth`/`naturalHeight` are the picture's own pixel size, and the only thing in the document
 * that says what the picture looks like: the aspect ratio of the box on the board is derived from them,
 * and they are written once, by the client that adds the image, from a decode of the file. Everything
 * else about the picture is in the bucket, addressed by `assetKey` - which is `null` right up until the
 * upload finishes, and is the reason a placeholder can be written immediately and drawn immediately.
 *
 * Unlike a stroke, an image has no field that has to be present for there to be something to draw: a
 * picture still waiting for its bytes is drawn as its own progress, not skipped. So the fields below are
 * optional on this interface in the way the others are, and it is {@link asImageSnapshot} that decides
 * what a missing one means.
 */
export interface ImageSnapshot extends ObjectSnapshot {
  readonly type: 'image';
  /** Where the bytes are, or `null` while they are still on their way. */
  readonly assetKey: string | null;
  /** The MIME type the bytes were found to be, which is what they are served as. */
  readonly contentType: string;
  /** The picture's own size, in pixels: the aspect ratio every box on the board is kept to. */
  readonly naturalWidth: number;
  readonly naturalHeight: number;
  /** How far the upload has got, as written by the uploader. See {@link displayStatus} for what is shown. */
  readonly status: ImageUploadStatus;
  /** When this upload started, epoch ms: the clock the "didn't finish" read is taken against. */
  readonly uploadStartedAt: number;
  /** Whose upload it is - the only reason the uploader is asked anything at all. */
  readonly uploaderId?: string;
}

/**
 * The object types this client can read.
 *
 * `snapshot` only reads types listed here, so a document written by a newer client - one that
 * already has shapes or frames in it - is still readable: its objects are skipped instead of
 * breaking the board. The client's object registry ({@link registerObjectReader}) adds a type
 * here when it registers the component that draws it, which is what lets a type be added in one
 * place and have the model, the renderer and the selection maths agree about it.
 */
const readableTypes = new Set<string>([STICKY_TYPE]);

/**
 * Let the model read objects of `type`. Called once per type by the client's object registry;
 * idempotent, and never removes a type (a document may already hold objects of it).
 */
export function registerObjectReader(type: string): void {
  if (type !== '') {
    readableTypes.add(type);
  }
}

/** Whether {@link snapshot} reads objects of this `type`. */
export function canReadObjectType(type: unknown): boolean {
  return typeof type === 'string' && readableTypes.has(type);
}

/**
 * Something that may delete other objects as a consequence of a deletion, in the same transaction.
 */
type DeletionObserver = (doc: Y.Doc, ids: readonly string[]) => void;

const deletionObservers = new Set<DeletionObserver>();

/**
 * Ask to be told when objects are deleted.
 *
 * The board cannot import the object types - they import the board - so a type with work to do when
 * something else leaves registers that work here, the same way it registers itself as readable.
 * There is one such piece of work today, and it belongs to arrows: an arrow attached to a shape
 * that is being deleted is detached from it first, so that no client, on no board, is ever left
 * looking at an arrowhead floating over the place a shape used to be. It runs inside
 * {@link deleteObjects}' transaction, which is what makes the two deletions one change to the board
 * - one undo, one update on the wire.
 *
 * @returns whether this exact observer was already registered (registering it twice is harmless)
 */
export function onObjectsDeleted(observer: DeletionObserver): boolean {
  const already = deletionObservers.has(observer);
  deletionObservers.add(observer);
  return already;
}

/**
 * Where an object is drawn, for a type whose box is not its own (story 10).
 *
 * Every other type owns its box: a note, a shape and a piece of text are drawn at the `x`, `y`,
 * `width` and `height` written in them. An arrow is drawn where its two ends are, and an end is
 * attached to another object - so its box is a consequence of that object's box, which is exactly
 * why an arrow follows a shape that is dragged across the board and needs nothing of anybody but
 * the next read of the document.
 *
 * The resolver is asked once per object per {@link snapshot}, with the boxes of everything on the
 * board that owns its own. The box it returns is written over the object's stored one, which is
 * what lets selection, marquee, bounds, paste and the Durable Object's validation keep asking the
 * one question they have always asked - `where is this object` - and get an answer that is true for
 * arrows too.
 */
export type BoundsResolver = (
  object: ObjectSnapshot,
  rects: ReadonlyMap<string, Rect>,
) => Rect | null;

const boundsResolvers = new Map<string, BoundsResolver>();

export function registerDerivedBounds(type: string, resolver: BoundsResolver): void {
  if (type !== '') {
    boundsResolvers.set(type, resolver);
  }
}

/** Whether objects of this `type` have a box that has to be worked out before it can be used. */
export function hasDerivedBounds(type: unknown): boolean {
  return typeof type === 'string' && boundsResolvers.has(type);
}

/**
 * Any board object, as the board reads it: the geometry every object has, plus the fields of
 * whichever type it is. Sticky notes are the only type today, which is why the type-specific
 * fields are always present; stories 9-12 turn this into a union and add `text`, `shape`,
 * `draw` and `image` fields to it.
 */
export interface ObjectSnapshot {
  readonly id: string;
  readonly type: string;
  readonly x: number;
  readonly y: number;
  /**
   * Size in world units. An object made before story 7 stores no size and reads back as
   * {@link STICKY_SIZE_WORLD}, which is the size it was drawn at then.
   */
  readonly width: number;
  readonly height: number;
  readonly color: StickyColor;
  /** The object's text, read from its `Y.Text` ('' for an object that has none). */
  readonly text: string;
  readonly z: number;
  readonly createdAt: number;
  /**
   * How big the letters of a text object are (story 9). Only a type that has a size has one, so
   * it is absent for a sticky note - which is why it is optional here rather than a field every
   * object is asked to fill in.
   */
  readonly size?: TextSize;
  /** Whether a text object's width follows its longest line or the width it was given. */
  readonly widthMode?: TextWidthMode;
  /**
   * A shape's kind, colours and label (story 10), when the object is a shape. Read the same generic
   * way `size` and `widthMode` are - a value that is not one of the named settings is left out and
   * the type's own reader falls back to its default - and optional for the same reason: a client
   * that has never heard of shapes must still be able to read a board that has them on it.
   */
  readonly kind?: ShapeKind;
  readonly fill?: FillColor;
  readonly stroke?: StrokeColor;
  readonly label?: string;
  /**
   * Where an arrow starts and where it ends (story 10), when the object is an arrow.
   *
   * These are the arrow's *cause*; its `x`/`y`/`width`/`height` above are its *consequence*, worked
   * out from these and from the box of whatever the ends are attached to (see
   * {@link registerDerivedBounds}). That is the whole reason an arrow follows a shape: nobody
   * rewrites the arrow when the shape moves, the arrow is simply asked where it is again.
   */
  readonly from?: Endpoint;
  readonly to?: Endpoint;
  /**
   * A pen stroke's colour, width, path and original box (story 11), when the object is a stroke.
   *
   * `points` is the path as the document stores it: a flat array of numbers, `[x0, y0, x1, y1, …]`,
   * measured *relative to the box* rather than the board - which is the whole trick of a stroke that
   * resizes, because scaling the box scales the drawing with it and costs no rewrite of the path (see
   * {@link scaledPoints}).
   *
   * The colour is called `penColor` on this generic snapshot and `color` on {@link StrokeSnapshot}, and
   * both are the document's one `color` field: a stroke writes its colour where every object keeps its
   * colour, but `color` on this interface is typed as a sticky note's colour, and a stroke's black, red
   * and purple are not members of that set. See {@link StrokeSnapshot} for the type that says so.
   */
  readonly penColor?: PenColor;
  readonly thickness?: PenThickness;
  readonly points?: readonly number[];
  /** The box the stroke was drawn at, which is the box its path is measured against. */
  readonly baseWidth?: number;
  readonly baseHeight?: number;
  /** Who made this object. There is no account system yet, so this is what the creating client
   * called itself; the board does not check it and nothing in the UI reads it. */
  readonly createdBy?: string;
  /**
   * An image's reference, size and upload state (story 12), when the object is an image.
   *
   * Read the same generic way as every other type's extra fields, and optional for the same reason: a
   * client that has never heard of images must still read a board that has them on it. `assetKey` is
   * `null` while an upload is in flight - the field is there, and says it has nothing in it yet.
   */
  readonly assetKey?: string | null;
  readonly contentType?: string;
  readonly naturalWidth?: number;
  readonly naturalHeight?: number;
  readonly status?: ImageUploadStatus;
  readonly uploadStartedAt?: number;
  readonly uploaderId?: string;
}

/**
 * A pen stroke (story 11), as the board reads it.
 *
 * The four fields only a stroke has are required here, because the stroke's own reader ({@link
 * asStrokeSnapshot}) gives all four a value: a stroke drawn in a colour this client has never heard of
 * is still drawn, in black, and not taken off the board. A stroke whose *path* cannot be read is the
 * exception - there is no default line to draw in its place - and such a stroke is not read at all, the
 * way an arrow whose ends cannot be read is not drawn.
 *
 * It is `Omit<ObjectSnapshot, 'color'>` rather than a plain extension, and that is the one type-level
 * decision of this story: the colour a stroke is drawn in is a *drawing* colour - black, red and purple
 * among them - and `color` on the generic snapshot is a *sticky note* colour, a set those three are not
 * members of. Rather than widen a field every story since story 2 reads, the stroke's colour is named
 * `color` here, where it can be given the right type, and reported as `penColor` on the generic
 * snapshot, where it cannot.
 */
export interface StrokeSnapshot extends Omit<ObjectSnapshot, 'color'> {
  readonly type: 'stroke';
  /** Which of the six pen colours the line is drawn in, from the document's `color` field. */
  readonly color: PenColor;
  /** Which of the three widths the line is drawn at, in world units by {@link PEN_THICKNESS_WORLD}. */
  readonly thickness: PenThickness;
  /** The path, flat and relative to the box: `[x0, y0, x1, y1, …]`. Never an odd length. */
  readonly points: readonly number[];
  /** The box the stroke was drawn at: the denominator of every resize since. */
  readonly baseWidth: number;
  readonly baseHeight: number;
}

/**
 * A shape (story 10), as the board reads it.
 *
 * The three fields only a shape has are required here, because the shape's own reader gives all
 * three a value: a shape written by a client that knew a kind this one does not is still drawn -
 * as a rectangle, in the default colours - rather than disappearing from the board. Story 9 did the
 * same for a text object's size.
 */
export interface ShapeSnapshot extends ObjectSnapshot {
  readonly type: 'shape';
  /** Which of the three shapes it is drawn as. */
  readonly kind: ShapeKind;
  /** Which of the palette's fills, or `'none'`. */
  readonly fill: FillColor;
  /** Which of the palette's outline colours. */
  readonly stroke: StrokeColor;
  /** The shape's label, '' when it has nothing written in it. */
  readonly label: string;
}

/**
 * Story 2's name for a readable object. Sticky notes are the only object type there is today,
 * so a sticky's snapshot is any object's snapshot; code that only understands notes keeps
 * saying this.
 */
export type StickySnapshot = ObjectSnapshot;

/**
 * A free text object (story 9), as the board reads it.
 *
 * The two fields a text object has that no other type has are required here, because the reader
 * gives both of them a value: an object written before a field existed, or carrying a size from a
 * future version this client does not know, reads back as the default rather than as nothing. That
 * is what lets the drawing code say `object.size` instead of asking what size an unknown size
 * means, at every place it draws.
 */
export interface TextSnapshot extends ObjectSnapshot {
  readonly type: 'text';
  /** Which of the four sizes the letters are drawn at. */
  readonly size: TextSize;
  /** Whether the width follows the longest line, or the width the last drag gave it. */
  readonly widthMode: TextWidthMode;
  /** Who made it, when the creating client recorded that. Nothing checks it and nothing shows it. */
  readonly createdBy?: string;
}

/** Point in world units. */
export interface WorldPoint {
  readonly x: number;
  readonly y: number;
}

type YObject = Y.Map<unknown>;

function objectsOf(doc: Y.Doc): Y.Map<YObject> {
  return doc.getMap<YObject>(OBJECTS_MAP);
}

/** True for one of the six colour names (runtime check: values arrive from the wire). */
export function isStickyColor(value: unknown): value is StickyColor {
  return typeof value === 'string' && Object.prototype.hasOwnProperty.call(STICKY_COLORS, value);
}

function isFinitePoint(x: number, y: number): boolean {
  return Number.isFinite(x) && Number.isFinite(y);
}

/** A member of `objects` that this version of the client knows how to read. */
function readableObject(objects: Y.Map<YObject>, id: string): YObject | null {
  const object = objects.get(id);
  if (object === undefined || !(object instanceof Y.Map) || !canReadObjectType(object.get('type'))) {
    return null;
  }
  return object;
}

/** A member of `objects` that is a sticky note this client can read. */
function stickyObject(objects: Y.Map<YObject>, id: string): YObject | null {
  const object = readableObject(objects, id);
  return object !== null && object.get('type') === STICKY_TYPE ? object : null;
}

function readZ(object: YObject): number {
  const z = object.get('z');
  return typeof z === 'number' && Number.isFinite(z) ? z : 0;
}

/** Highest stacking order of any readable object; 0 for an empty document. */
function maxZ(objects: Y.Map<YObject>): number {
  let max = 0;
  for (const object of objects.values()) {
    if (object instanceof Y.Map && canReadObjectType(object.get('type'))) {
      max = Math.max(max, readZ(object));
    }
  }
  return max;
}

/**
 * Ids are `crypto.randomUUID()`, so notes created offline by different peers (story 3)
 * never collide. The fallback only runs where the Web Crypto UUID helper is missing.
 */
function newId(): string {
  // `crypto` is a global in the browser and in the Worker; read it as one, not as a property
  // of `globalThis`, which only the browser's type library puts there.
  const cryptoObject: Crypto | undefined = typeof crypto === 'undefined' ? undefined : crypto;
  if (typeof cryptoObject?.randomUUID === 'function') {
    return cryptoObject.randomUUID();
  }
  const random = Math.random().toString(36).slice(2, 10);
  return `${Date.now().toString(36)}-${random}`;
}

/**
 * Prepare a document for use, recording the schema version once. An existing version -
 * including one written by a newer client - is left alone, so loading a stored document
 * never rewrites its metadata.
 */
export function initDoc(doc: Y.Doc): void {
  const meta = doc.getMap<number>(META_MAP);
  if (typeof meta.get('schemaVersion') === 'number') {
    return;
  }
  doc.transact(() => {
    meta.set('schemaVersion', SCHEMA_VERSION);
  }, LOCAL_ORIGIN);
}

/**
 * Add a sticky note centred on `at` (the stored `x`/`y` are the top-left, hence the
 * half-size offset) and on top of every existing note.
 *
 * @returns the new id, or `''` when the point or colour was rejected.
 */
export function createSticky(
  doc: Y.Doc,
  at: WorldPoint,
  color: StickyColor = DEFAULT_STICKY_COLOR,
): string {
  if (!isFinitePoint(at.x, at.y) || !isStickyColor(color)) {
    return '';
  }
  const id = newId();
  doc.transact(() => {
    const objects = objectsOf(doc);
    const object = new Y.Map<unknown>();
    object.set('type', STICKY_TYPE);
    object.set('x', at.x - STICKY_SIZE_WORLD / 2);
    object.set('y', at.y - STICKY_SIZE_WORLD / 2);
    object.set('color', color);
    object.set('text', new Y.Text());
    object.set('z', maxZ(objects) + 1);
    object.set('createdAt', Date.now());
    objects.set(id, object);
  }, LOCAL_ORIGIN);
  return id;
}

/**
 * Move a note to a new top-left, in world units. Moving a note onto the position it
 * already has is a no-op (`false`), which keeps drag frames from emitting updates.
 *
 * A single move in terms of {@link moveObjects}, so that moving one object and moving a
 * selection go through the same code and behave the same way.
 */
export function moveObject(doc: Y.Doc, id: string, x: number, y: number): boolean {
  return moveObjects(doc, new Map([[id, { x, y }]])) > 0;
}

/**
 * Move a set of objects, each to its own new top-left, in world units.
 *
 * This is what a group drag writes: one transaction for the whole selection, so 200 selected
 * objects move as one change and one undo (story 8) puts them all back. An id that is not in
 * the document any more - a peer deleted it mid-drag - is skipped rather than recreated, and a
 * position that is not finite rejects the whole call: half a group moving to nowhere is worse
 * than none of it moving.
 *
 * @returns how many objects actually moved (0 when none of them needed to)
 */
export function moveObjects(doc: Y.Doc, positions: ReadonlyMap<string, Point>): number {
  const objects = objectsOf(doc);
  const targets: { object: YObject; x: number; y: number }[] = [];
  for (const [id, point] of positions) {
    const object = readableObject(objects, id);
    if (object === null) {
      continue;
    }
    if (!isFinitePoint(point.x, point.y)) {
      return 0;
    }
    if (object.get('x') === point.x && object.get('y') === point.y) {
      continue;
    }
    targets.push({ object, x: point.x, y: point.y });
  }
  if (targets.length === 0) {
    return 0;
  }
  doc.transact(() => {
    for (const target of targets) {
      target.object.set('x', target.x);
      target.object.set('y', target.y);
    }
  }, LOCAL_ORIGIN);
  return targets.length;
}

/**
 * Resize and reposition a set of objects at once, from the boxes a group resize produced.
 *
 * One transaction, skipped ids, and the same rejection of non-finite geometry as
 * {@link moveObjects}; the caller has already scaled and clamped the boxes, so nothing here
 * knows about handles, aspect ratios or minimum sizes.
 *
 * @returns how many objects actually changed
 */
export function resizeObjects(doc: Y.Doc, rects: ReadonlyMap<string, Rect>): number {
  const objects = objectsOf(doc);
  const targets: { object: YObject; rect: Rect }[] = [];
  for (const [id, rect] of rects) {
    const object = readableObject(objects, id);
    if (object === null) {
      continue;
    }
    if (
      !Number.isFinite(rect.x) ||
      !Number.isFinite(rect.y) ||
      !Number.isFinite(rect.width) ||
      !Number.isFinite(rect.height) ||
      rect.width <= 0 ||
      rect.height <= 0
    ) {
      return 0;
    }
    if (
      object.get('x') === rect.x &&
      object.get('y') === rect.y &&
      object.get('width') === rect.width &&
      object.get('height') === rect.height
    ) {
      continue;
    }
    targets.push({ object, rect });
  }
  if (targets.length === 0) {
    return 0;
  }
  doc.transact(() => {
    for (const target of targets) {
      target.object.set('x', target.rect.x);
      target.object.set('y', target.rect.y);
      target.object.set('width', target.rect.width);
      target.object.set('height', target.rect.height);
    }
  }, LOCAL_ORIGIN);
  return targets.length;
}

/**
 * Stack the given objects above every other object, keeping their order among themselves.
 *
 * The whole selection goes to the front in one transaction. The new `z` values are handed out
 * from the highest `z` of the objects that stayed behind, in the order the objects are already
 * drawn in, so a selection of three does not land as three equal values - which is what keeps
 * the notes the person picked in the order they were in, instead of shuffling them into an
 * arbitrary one. Already-on-top objects keep their place and cost no update.
 *
 * @returns how many objects changed
 */
export function bringObjectsToFront(doc: Y.Doc, ids: readonly string[]): number {
  const objects = objectsOf(doc);
  const selected = new Set(ids);
  const moving: { id: string; object: YObject; z: number }[] = [];
  let top = 0;
  for (const [id, object] of objects.entries()) {
    if (!(object instanceof Y.Map) || !canReadObjectType(object.get('type'))) {
      continue;
    }
    const z = readZ(object);
    if (selected.has(id)) {
      moving.push({ id, object, z });
    } else {
      top = Math.max(top, z);
    }
  }
  if (moving.length === 0) {
    return 0;
  }
  // The order the board draws them in, so the front-to-back order of the selection is kept.
  moving.sort((a, b) => (a.z !== b.z ? a.z - b.z : a.id < b.id ? -1 : a.id > b.id ? 1 : 0));
  // An object that is already higher than its new place is left where it is: bringing a
  // selection to the front never pushes part of it backwards.
  const target = moving.map((entry, index) => Math.max(entry.z, top + index + 1));
  const changed = moving.filter((entry, index) => target[index] !== entry.z).length;
  if (changed === 0) {
    return 0;
  }
  doc.transact(() => {
    moving.forEach((entry, index) => {
      const z = target[index];
      if (z !== undefined && z !== entry.z) {
        entry.object.set('z', z);
      }
    });
  }, LOCAL_ORIGIN);
  return changed;
}

/**
 * Stack a note above every other one. Returns `false` when it is already on top, so a
 * drag that grabs the top note costs no update.
 */
export function bringToFront(doc: Y.Doc, id: string): boolean {
  return bringObjectsToFront(doc, [id]) > 0;
}

/**
 * Change a note's colour, leaving text, position, stacking and creation time untouched.
 * Unknown colour names and stale ids are rejected.
 */
export function setStickyColor(doc: Y.Doc, id: string, color: string): boolean {
  if (!isStickyColor(color)) {
    return false;
  }
  const object = stickyObject(objectsOf(doc), id);
  if (object === null || object.get('color') === color) {
    return false;
  }
  doc.transact(() => {
    object.set('color', color);
  }, LOCAL_ORIGIN);
  return true;
}

/**
 * Remove one object (and with it its `Y.Text`). A stale id is rejected.
 *
 * A single delete in terms of {@link deleteObjects}.
 */
export function deleteObject(doc: Y.Doc, id: string): boolean {
  return deleteObjects(doc, [id]) > 0;
}

/**
 * Delete a set of objects in one transaction: what the Delete key and the selection bar's
 * Delete button do to a multi-selection.
 *
 * Ids that are not in the document any more are skipped - a peer got there first, the group is
 * still deleted - so a selection that went stale mid-action never brings an object back.
 *
 * @returns how many objects were deleted
 */
export function deleteObjects(doc: Y.Doc, ids: readonly string[]): number {
  const objects = objectsOf(doc);
  const present = new Set<string>();
  for (const id of ids) {
    if (readableObject(objects, id) !== null) {
      present.add(id);
    }
  }
  if (present.size === 0) {
    return 0;
  }
  doc.transact(() => {
    // Whatever was pointing at these objects is told first, and its work goes in the same
    // transaction: a board saved in between the two would be a board with an arrow pointing at
    // nothing, which is the one thing story 10 promises nobody ever sees.
    const gone = [...present];
    for (const observer of deletionObservers) {
      observer(doc, gone);
    }
    for (const id of present) {
      objects.delete(id);
    }
  }, LOCAL_ORIGIN);
  return present.size;
}

/**
 * The object's text as a `Y.Text`, so typing merges character-wise with other peers
 * (story 3) instead of overwriting them. `undefined` for a stale or unreadable object.
 */
export function getStickyText(doc: Y.Doc, id: string): Y.Text | undefined {
  const object = readableObject(objectsOf(doc), id);
  const text = object?.get('text');
  return text instanceof Y.Text ? text : undefined;
}

/** A positive stored size, or the size every object was before story 7 let them be resized. */
/**
 * The size an object of `type` is drawn at when the document holds no size for it.
 *
 * A note is 240 units square, because that is the only size a note has ever been. A shape gets the
 * size a click gives it, so an object written by a client that did not store a size is drawn the way
 * it would be drawn by a click today rather than at the size of a note. An arrow is the odd one: it
 * has no size of its own at all - it is drawn where its ends are - so it is read at nothing and
 * given its box from its ends a few lines later, or dropped if they cannot be read.
 */
function defaultSize(type: unknown): number {
  if (type === SHAPE_TYPE) {
    return SHAPE_DEFAULT_SIZE_WORLD;
  }
  return type === CONNECTOR_TYPE ? 0 : STICKY_SIZE_WORLD;
}

function readSize(object: YObject, key: string, type: unknown): number {
  const size = object.get(key);
  return typeof size === 'number' && Number.isFinite(size) && size > 0
    ? size
    : defaultSize(type);
}

/**
 * Read one object, or `null` when a peer wrote something this client cannot render.
 *
 * A sticky note is only readable with a colour and a `Y.Text` of its own, because a note without
 * either could not be drawn. Other readable types are held to their geometry alone: an object of
 * a type a later story adds that has no text of its own is not malformed. What is held to the same
 * rule wherever it comes from is a text that is not a `Y.Text`: an object whose text is a plain
 * string cannot be typed into or merged with, so an object that has a `text` field of the wrong
 * kind is skipped rather than drawn with somebody else's idea of a string in it.
 *
 * The fields no other type has - `size`, `widthMode` - are read the same generic way, because the
 * object type modules cannot be imported here without a cycle (they read the model to be written
 * at all): a value that is not one of the named settings is left out, and the type's own reader
 * falls back to its default.
 */
function readObject(id: string, object: YObject): ObjectSnapshot | null {
  const type = object.get('type');
  const x = object.get('x');
  const y = object.get('y');
  const color = object.get('color');
  const text = object.get('text');
  const z = object.get('z');
  const createdAt = object.get('createdAt');
  const size = object.get('size');
  const widthMode = object.get('widthMode');
  const kind = object.get('kind');
  const fill = object.get('fill');
  const stroke = object.get('stroke');
  const label = object.get('label');
  const createdBy = object.get('createdBy');
  const points = readPoints(object.get('points'));
  const thickness = object.get('thickness');
  const baseWidth = object.get('baseWidth');
  const baseHeight = object.get('baseHeight');
  const assetKey = object.get('assetKey');
  const contentType = object.get('contentType');
  const naturalWidth = object.get('naturalWidth');
  const naturalHeight = object.get('naturalHeight');
  const status = object.get('status');
  const uploadStartedAt = object.get('uploadStartedAt');
  const uploaderId = object.get('uploaderId');
  if (
    typeof x !== 'number' ||
    typeof y !== 'number' ||
    !Number.isFinite(x) ||
    !Number.isFinite(y) ||
    typeof z !== 'number' ||
    !Number.isFinite(z)
  ) {
    return null;
  }
  if (type === STICKY_TYPE) {
    if (!isStickyColor(color) || !(text instanceof Y.Text)) {
      return null;
    }
  } else if (text !== undefined && !(text instanceof Y.Text)) {
    return null;
  }
  // A label is typed into, and merged with somebody else's typing, exactly like a `text` field is,
  // so it is held to the same rule: a plain string where a `Y.Text` belongs is not readable.
  if (label !== undefined && !(label instanceof Y.Text)) {
    return null;
  }
  // A stroke with no path is a line nobody drew, and there is no default line to draw instead: it is
  // dropped the way an arrow with unreadable ends is. Story 10's rule for a box of not-a-number.
  if (type === STROKE_TYPE && points === null) {
    return null;
  }
  // An image with no natural size is the same case one story on: the size is not metadata, it is the
  // aspect ratio, and an image drawn at no ratio is a grey box that lies about the picture in it. Its
  // bytes may or may not be in the bucket - that is not a reason to draw a box with no shape in it.
  if (type === IMAGE_TYPE && !(isPositiveNumber(naturalWidth) && isPositiveNumber(naturalHeight))) {
    return null;
  }
  return {
    id,
    type: typeof type === 'string' ? type : STICKY_TYPE,
    x,
    y,
    width: readSize(object, 'width', type),
    height: readSize(object, 'height', type),
    color: isStickyColor(color) ? color : DEFAULT_STICKY_COLOR,
    text: text instanceof Y.Text ? text.toString() : '',
    z,
    createdAt: typeof createdAt === 'number' ? createdAt : 0,
    ...(isTextSize(size) ? { size } : {}),
    ...(isTextWidthMode(widthMode) ? { widthMode } : {}),
    ...(isShapeKind(kind) ? { kind } : {}),
    ...(isFillColor(fill) ? { fill } : {}),
    ...(isStrokeColor(stroke) ? { stroke } : {}),
    ...(label instanceof Y.Text ? { label: label.toString() } : {}),
    ...(readEndpoint(object.get('from')) !== null ? { from: readEndpoint(object.get('from'))! } : {}),
    ...(readEndpoint(object.get('to')) !== null ? { to: readEndpoint(object.get('to'))! } : {}),
    ...(isPenColor(color) ? { penColor: color } : {}),
    ...(isPenThickness(thickness) ? { thickness } : {}),
    ...(points !== null ? { points } : {}),
    ...(isPositiveNumber(baseWidth) ? { baseWidth } : {}),
    ...(isPositiveNumber(baseHeight) ? { baseHeight } : {}),
    ...(typeof createdBy === 'string' && createdBy !== '' ? { createdBy } : {}),
    // Story 12's image fields. `assetKey` is the one field on this interface that may legitimately be
    // null, and the null is kept: "uploading, no bytes yet" and "not an image" are different answers and
    // only conflating them would be cheap.
    ...(typeof assetKey === 'string' || assetKey === null ? { assetKey } : {}),
    ...(typeof contentType === 'string' && contentType !== '' ? { contentType } : {}),
    ...(isPositiveNumber(naturalWidth) ? { naturalWidth } : {}),
    ...(isPositiveNumber(naturalHeight) ? { naturalHeight } : {}),
    ...(isImageUploadStatus(status) ? { status } : {}),
    ...(typeof uploadStartedAt === 'number' && Number.isFinite(uploadStartedAt) ? { uploadStartedAt } : {}),
    ...(typeof uploaderId === 'string' && uploaderId !== '' ? { uploaderId } : {}),
  };
}

/**
 * The path of a stroke, as stored: a flat, even-length array of finite numbers. `null` for anything
 * else, including an array with a `NaN` in it or an odd length - half a point is not a point.
 */
function readPoints(value: unknown): readonly number[] | null {
  if (!Array.isArray(value) || value.length === 0 || value.length % 2 !== 0) {
    return null;
  }
  for (const part of value) {
    if (typeof part !== 'number' || !Number.isFinite(part)) {
      return null;
    }
  }
  return value as readonly number[];
}

function isPositiveNumber(value: unknown): value is number {
  return typeof value === 'number' && Number.isFinite(value) && value > 0;
}

/**
 * Render order: objects sorted by `(z, id)`. The id tie-break matters as soon as two peers
 * stack at the same time (story 3): equal `z` values still give every client the same
 * order. Objects of unknown `type` - the frames of later stories - and malformed notes are
 * skipped rather than thrown on.
 *
 * An object whose box is derived - an arrow, today - is read twice: once for what it is, and then
 * once more with its box worked out from the objects its ends are attached to. The boxes of the
 * objects that own their own are all known before any derived one is asked, so an arrow attached
 * to a shape that was moved one transaction ago is drawn where that shape now is.
 */
export function snapshot(doc: Y.Doc): readonly ObjectSnapshot[] {
  const objects: ObjectSnapshot[] = [];
  for (const [id, object] of objectsOf(doc).entries()) {
    if (!(object instanceof Y.Map) || !canReadObjectType(object.get('type'))) {
      continue;
    }
    const read = readObject(id, object);
    if (read !== null) {
      objects.push(read);
    }
  }
  objects.sort(compareNotes);
  return resolveDerivedBoxes(objects);
}

/** The boxes of everything that carries its own, in the order the board draws things. */
function intrinsicRects(objects: readonly ObjectSnapshot[]): Map<string, Rect> {
  const rects = new Map<string, Rect>();
  for (const object of objects) {
    if (!hasDerivedBounds(object.type)) {
      rects.set(object.id, objectBounds(object));
    }
  }
  return rects;
}

/** Write every derived box over the object it belongs to, dropping what cannot be drawn. */
function resolveDerivedBoxes(objects: readonly ObjectSnapshot[]): ObjectSnapshot[] {
  const derived = objects.filter((object) => hasDerivedBounds(object.type));
  if (derived.length === 0) {
    // The answer for every board without arrows in it, which is every board until story 10.
    return [...objects];
  }
  const rects = intrinsicRects(objects);
  const result: ObjectSnapshot[] = [];
  for (const object of objects) {
    const resolver = boundsResolvers.get(object.type);
    if (resolver === undefined) {
      result.push(object);
      continue;
    }
    const box = resolver(object, rects);
    if (box === null) {
      // It is on the board, but this client cannot tell where it would be drawn. Story 9's rule for
      // a box of not-a-number applies unchanged: an object with no box is not drawn, not selected
      // and not hit - and an arrow with no line to draw is not an arrow.
      continue;
    }
    result.push({ ...object, x: box.x, y: box.y, width: box.width, height: box.height });
  }
  return result;
}

function compareNotes(a: ObjectSnapshot, b: ObjectSnapshot): number {
  if (a.z !== b.z) {
    return a.z - b.z;
  }
  return a.id < b.id ? -1 : a.id > b.id ? 1 : 0;
}

/**
 * The box an object takes up on the board, in world units. Every object type has one, which is
 * what the marquee, the selection outline, the bounding box and the resize maths all work on.
 */
export function objectBounds(object: ObjectSnapshot): Rect {
  return { x: object.x, y: object.y, width: object.width, height: object.height };
}

/**
 * Which objects the marquee box selects: the ones it contains *completely*, in the order the
 * board draws them.
 *
 * The PRD says an object "is selected only if it lies completely within the rectangle", so this
 * is containment and not intersection - the difference a test can only see at the edge, which is
 * why it is stated here rather than left to be inferred.
 */
export function objectsInRect(objects: readonly ObjectSnapshot[], rect: Rect): string[] {
  if (!Number.isFinite(rect.width) || !Number.isFinite(rect.height)) {
    return [];
  }
  return objects.filter((object) => rectContains(rect, objectBounds(object))).map((object) => object.id);
}

/** Every object the board holds and this client can draw, in draw order. `Ctrl/Cmd + A` selects them. */
export function allObjectIds(objects: readonly ObjectSnapshot[]): string[] {
  return objects.map((object) => object.id);
}

/**
 * The smallest box that holds a whole selection, or `null` when there is nothing to draw a box
 * around. The selection bar and the resize handles are placed from this.
 */
export function selectionBounds(objects: readonly ObjectSnapshot[], ids: Iterable<string>): Rect | null {
  const wanted = new Set(ids);
  return unionRects(
    objects.filter((object) => wanted.has(object.id)).map((object) => objectBounds(object)),
  );
}
